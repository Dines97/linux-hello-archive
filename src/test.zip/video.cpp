#include "video.h"
void video::add_snapshot(snapshot& s) {
    video_record.push_back(s);
}
